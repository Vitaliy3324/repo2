﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private ApplicationContext db;

        public HomeController(ILogger<HomeController> logger, ApplicationContext context)
        {
            _logger = logger;

            db = context;


        }



        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {


            return View("Create");
        }

        [Route("{id:int}")]
        [HttpGet]
        public IActionResult GetLink(int id)
        {
            LinkItem? itm = db.LItems.FirstOrDefault<LinkItem>(u => u.Id == id);

            if (itm != null)
                return Redirect(itm.Link);
            else
                return RedirectToAction("Index");
            //return View();
        }


        [Route("")]
        [HttpPost]
        public string Create(LinkItem linkItem)
        {
            LinkItem jj = new LinkItem();
            jj.Link = linkItem.Link;

 

            db.LItems.Add(jj);


            string kkkk = this.Request.Host.ToString();
            db.SaveChanges();

            return "короткая ссылка для " + jj.Link + ": " + kkkk + "/" + jj.Id;//RedirectToAction("Index");
        } 
        //[Route("")]
        //[HttpPost] +
        //public async Task<IActionResult> Create(LinkItem linkItem)
        //{
        //    LinkItem jj = new LinkItem();
        //    jj.Link = "hh.ru";//linkItem.Link;


        //    db.LItems.Add(jj);

        //    await db.SaveChangesAsync();

        //    return RedirectToAction("Index");
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
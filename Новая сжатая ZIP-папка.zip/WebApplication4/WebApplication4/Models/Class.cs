﻿namespace WebApplication4.Models
{
    public class LinkItem
    {
        public int Id { get; set; }
        public string Link { get; set; } = "";

    }
}

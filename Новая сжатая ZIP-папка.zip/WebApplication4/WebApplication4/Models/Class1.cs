﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication4.Models
{
    public class ApplicationContext : DbContext
    {
        public DbSet<LinkItem> LItems { get; set; } = null!;
        public ApplicationContext(DbContextOptions<ApplicationContext> options)
            : base(options)
        {
            Database.EnsureCreated();   // создаем базу данных при первом обращении
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LinkItem>().HasData(
                    new LinkItem { Id = 1, Link = "ggogle.com" },
                    new LinkItem { Id = 2, Link = "yandex.ru" },
                    new LinkItem { Id = 3, Link = "youtube.com" }
            );
        }

    }
}



